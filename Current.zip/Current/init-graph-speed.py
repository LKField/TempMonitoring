import csv
import glob
import time

import dash
import dash_core_components as dcc
import dash_html_components as html
import plotly.graph_objs as go
import pandas as pd

file_list = glob.glob('*.csv')
print(file_list)

dates = []
temps = []
humids = []

def old_way(file_list):
    t_s = time.time()       # Start time
    dates = []
    temps = []
    humids = []
    for name in file_list:
        with open(name) as csvfile:
            my_data = csv.reader(csvfile) # read in csv file
            next(my_data, None)

            for row in my_data: # read in and format rows
                date = row[0]
                temp = row[1]
                humid = row[2]

                dates.append(date)
                temps.append(temp)
                humids.append(humid)

                form_dates = pd.to_datetime(dates) # convert column 1 to datetime

    print("Time to run 'old_way is {:}".format(time.time()-t_s))
    # print(form_dates)
    return form_dates, temps, humids


def new_way(file_list):
    t_s = time.time()
    dfs = []
    for name in file_list:
        df = pd.read_csv(name, names=['daytime', 'temp', 'humd'],
                         skiprows=1, converters={'daytime' : pd.to_datetime})
        # df.daytime = pd.to_datetime(df.daytime)
        dfs.append(df)
    df = pd.concat(dfs)
    print("Time to run 'new_way is {:}".format(time.time()-t_s))
    return df.daytime, df.temp, df.humd


form_dates, temps, humids = old_way(file_list)

form_dates, temps, humids = new_way(file_list)
#print(temps)
#print(humids)

exit(1)

trace1 = go.Scatter(x=form_dates, y=temps, name='Temperature (F)')
trace2 = go.Scatter(x=form_dates, y=humids, name='Relative Humidity (%)')


app = dash.Dash()
app.layout = html.Div(children=[
    html.H1(children='Demo Lab 1 Norwood Temperature and Humidity Data'),
    dcc.Graph(
        id='temperature-graph',
        figure={
            'data': [trace1],
            'layout':
            go.Layout(title='Temperature (F)')
        }),
    dcc.Graph(
        id='humidity-graph',
        figure={
            'data': [trace2],
            'layout':
            go.Layout(title='Relative Humidity (%)')
        })
])

if __name__ == '__main__':
    app.run_server(debug=True)
