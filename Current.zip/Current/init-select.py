# -*- coding: utf-8 -*-

import os
import os.path
from pprint import pprint as pp
import shlex, subprocess                    # Used to open Safari

import dash
import dash_core_components as dcc
import dash_html_components as html
from dash.dependencies import Input, Output, State
import pandas as pd
import plotly.graph_objs as go
import csv

# This gets the list of file names in the current folder.
# A different path can be specified and I am sure there is a way
# to make this user pickable.
root = os.path.abspath(os.getcwd())
starting_root = os.path.dirname(root)
print(root)
file_names = os.listdir(root)
# This print just confirms that we got a list.
print("Source files")
print(file_names)
print("Filtered names")
file_names = filter( lambda f: (f.find(".csv")>=0), file_names )
print(type(file_names))
print(file_names)

# It is possible to filter this list so that only excel files are included.
dates = []
temps = []
humids = []

# open all the .csv files and create separated data lists
for name in file_names:
    #print("After 'for' Opening:", name)
    with open(name) as csvfile:
        print("Just .csv: ", name)
        my_data = csv.reader(csvfile) # read in csv file
        next(my_data, None)

        for row in my_data: # read in and format rows
            date = row[0]
            temp = row[1]
            humid = row[2]

            dates.append(date)
            temps.append(temp)
            humids.append(humid)

            form_dates = pd.to_datetime(dates) # convert column 1 to datetime

app = dash.Dash()

# This defines a dropdown menu populated with all of the files in the folder
hello_ = [{'label': "..", 'value': ".."}] + [{'label': x, 'value': x} for x in file_names]
print(hello_)

root_box = \
    dcc.Textarea(
        id="root",
        placeholder='Enter a value...',
        value=root,
        style={'width': '100%'}
    )

select = html.Div([
    dcc.Dropdown(
        id='select',
        placeholder='Pick a file.',
        options=hello_,
        )
    ],
    style={'width' : '25%',
           'display' : 'inline-block'}
    )
select.Path = os.path.abspath(".")
select.available_properties.append('Path')

# box = dcc.Input(id='pick', value='initial value', type='text')
#
axis_tempplate = {'showgrid' : True,
                  'zeroline' : True,
                  'showline' : True,
                  'title'    : 'x title',
                  }

# This defines a graph that currently has nothing in it.
graph = dcc.Graph(id='graph',
                  # title= 'Stats of USA States'
                  config={'displayModeBar': False}
                  )

# This tells dash about the two objects.
app.layout = html.Div(children=[root_box, select, graph

] )

# The "@" defines a 'decorator' which does something to the following
# function. In this case, the decorator defines a source (the drop down menu)
# and defines a destination (the graph).
# The following function (update_graph) converts the input (a file name)
# into an output (the specifications for a plot). There can be more than one
# # souce, which is why it is in a list.

@app.callback(
    Output(component_id='root', component_property='value'),
    [Input(component_id='select', component_property='value')],
    [State('root', 'value')
    # [Input(component_id='graph', component_property='clickData')],
    # [Input(component_id='graph', component_property='selectedData')]
     ]
)
def update_root(select, root):
    print("In update_root. ", type(select), type(root), select, root)
    if (select is None) or (select == '---'):
        return root
    if (select == "..") and (root == starting_root):
        return root
    target = os.path.abspath(os.path.join(root, select))
    if os.path.isdir(target):
        return target
    else:
        return root
    # print "In update_select", type(file_name), file_name, type(root), root
    # return


@app.callback(
    Output(component_id='select', component_property='options'),
    [Input(component_id='root', component_property='value')],
    [State('select', 'value')]
     # Input(component_id='graph', component_property='clickData')
     # Input(component_id='graph', component_property='selectedData')
     # ]
)
def update_select_options(root, select):
    print("In update_select_options. ", type(root), type(select), root, select)
    dir_names = [n for n in os.listdir(root) if os.path.isdir(os.path.join(root,n))]
    file_names = [n for n in os.listdir(root) if os.path.isfile(os.path.join(root,n))]
    values = [{'label': "..", 'value': ".."}] + \
             [{'label': x, 'value': x} for x in dir_names] + \
             [{'label': "---------", 'value': None}] + \
             [{'label': x, 'value': x} for x in file_names]
    return values


def update_graph(file_names):
    # return a defined state if no file is picked
    if file_names is None:
        return None
    print("In update_graph. You've selected'{}'".format(file_names))              # For debug
    # create and sort the data frame based on input
    df = pd.DataFrame({"date": form_dates, "temp": temps, "humid": humids})
    df = df.sort_values(by=['date'])
    # create traces
    trace1 = go.Scatter(x=df.date, y=df.temp, name='Temperature (F)')
    trace2 = go.Scatter(x=df.date, y=df.humid, name='Humidity (%)')
    # actually graph the data
    dcc.Graph(
        id='graph',
        figure={
            'data': [trace1, trace2],
            'layout':
            go.Layout(title=file_names)
        })

    return {
        'data' : [trace1, trace2]
    }




if __name__ == '__main__':
    print("Running main.")

    # Open a Safari window to open -a Safari http://127.0.0.1:8050
    # subprocess.check_call(shlex.split("open -a Safari http://127.0.0.1:8050"))

    app.run_server(debug=True)


"""
I found this source helpful
http://pbpython.com/plotly-dash-intro.html

Other references:
https://dash.plot.ly/getting-started-part-2
https://medium.com/@plotlygraphs/introducing-plotly-py-3-0-0-7bb1333f69c6
https://plot.ly/python/line-and-scatter/
https://plot.ly/python/reference/

dash conda installations instructions at
https://stackoverflow.com/questions/49613878/python-install-dash-with-conda
conda install -c conda-forge dash-renderer
conda install -c conda-forge dash
conda install -c conda-forge dash-html-components
conda install -c conda-forge dash-core-components
conda install -c conda-forge plotly

"""
