import csv
import glob
import time
import os

import dash
import dash_core_components as dcc
import dash_html_components as html
from dash.dependencies import Input, Output
import plotly.graph_objs as go
import pandas as pd

cdir = os.getcwd()
folder_list = (next(os.walk(cdir))[1])
print(folder_list)

#find the .csv files
file_list = cdir('*.csv')
print(file_list)
