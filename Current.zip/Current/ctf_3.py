# -*- coding: utf-8 -*-

import os
import os.path
from pprint import pprint as pp
import shlex, subprocess                    # Used to open Safari

import csv
import glob
import time

import dash
import dash_core_components as dcc
import dash_html_components as html
from dash.dependencies import Input, Output, State
import pandas as pd
import plotly.graph_objs as go

# This gets the list of file names in the current folder.
# A different path can be specified and I am sure there is a way
# to make this user pickable.
root = os.path.abspath(os.getcwd())
starting_root = os.path.dirname(root)
print(root)
file_names = os.listdir(root)
# This print just confirms that we got a list.
print("Source files")
print(file_names)
print("Filtered names")
file_names = filter( lambda f: (f.find(".csv")>=0), file_names )
print(type(file_names))
print(file_names)
# It is possible to filter this list so that only excel files are included.

# # Construct a list of time values, mean values, and temperatures.
# means = []
# for name in file_names:
#     d = pd.read_excel(name, header=1)
#     means.append(pd.DataFrame([list(d.mean())+ [name]], index=[d['Date'][0]], columns=['Temp (C)', 'Temp2', 'File']) )
# m = pd.concat(means)

app = dash.Dash()

# This defines a dropdown menu populated with all of the files in the folder
hello_ = [{'label': "..", 'value': ".."}] + [{'label': x, 'value': x} for x in file_names]
print(hello_)

root_box = \
    dcc.Textarea(
        id="root",
        placeholder='Enter a value...',
        value=root,
        style={'width': '100%'}
    )

select = html.Div([
    dcc.Dropdown(
        id='select',
        placeholder='Pick a file.',
        options=hello_,
        )
    ],
    style={'width' : '25%',
           'display' : 'inline-block'}
    )
select.Path = os.path.abspath(".")
select.available_properties.append('Path')

# box = dcc.Input(id='pick', value='initial value', type='text')
#
axis_tempplate = {'showgrid' : True,
                  'zeroline' : True,
                  'showline' : True,
                  'title'    : 'x title',
                  }

# This defines a graph that currently has nothing in it.
graph = dcc.Graph(id='graph',
                  # title= 'Stats of USA States'
                  config={'displayModeBar': False}
                  )


#find the .csv files
file_list = glob.glob('*.csv')
print(file_list)

def get_data(file_list):
    t_s = time.time()
    dfs = []
    for name in file_list:
        df = pd.read_csv(name, names=['daytime', 'temp', 'humd'],
                         skiprows=1, converters={'daytime' : pd.to_datetime})
        df.daytime = pd.to_datetime(df.daytime)
        dfs.append(df)
    df = pd.concat(dfs)
    df = df.sort_values(by=['daytime'])
    print("Time to run 'get_data is {:}".format(time.time()-t_s))
    return df, df.daytime, df.temp, df.humd

df, form_dates, temps, humids = get_data(file_list)
# print(form_dates)
# print(temps)
# print(humids)
# print(df)

trace1 = go.Scatter(x=form_dates, y=temps, name='Temperature (F)')
trace2 = go.Scatter(x=form_dates, y=humids, name='Humidity (%)')

app = dash.Dash()

graph = html.Div([
    dcc.Graph(
        id='graph',
        figure={
            'data': []
        })
])

# This tells dash about the two objects.
app.layout = html.Div(children=[root_box, select, graph

] )



@app.callback(
    Output(component_id='root', component_property='value'),
    [Input(component_id='select', component_property='value')],
    [State('root', 'value'),
     # Input(component_id='graph', component_property='clickData')
     # Input(component_id='graph', component_property='selectedData')
     ]
)
def update_root(select, root):
    print("In update_root. ", type(select), type(root), select, root)
    if (select is None) or (select == '---'):
        return root
    if (select == "..") and (root == starting_root):
        return root
    target = os.path.abspath(os.path.join(root, select))
    if os.path.isdir(target):
        return target
    else:
        return root
    # print "In update_select", type(file_name), file_name, type(root), root
    # return


@app.callback(
    Output(component_id='select', component_property='options'),
    [Input(component_id='root', component_property='value')],
    [State('select', 'value')]
     # Input(component_id='graph', component_property='clickData')
     # Input(component_id='graph', component_property='selectedData')
     # ]
)
def update_select_options(root, select):
    print("In update_select_options. ", type(root), type(select), root, select)
    dir_names = [n for n in os.listdir(root) if os.path.isdir(os.path.join(root,n))]
    file_names = [n for n in os.listdir(root) if os.path.isfile(os.path.join(root,n))]
    values = [{'label': "..", 'value': ".."}] + \
             [{'label': x, 'value': x} for x in dir_names] + \
             [{'label': "---------", 'value': None}] + \
             [{'label': x, 'value': x} for x in file_names]
    return values

# The "@" defines a 'decorator' which does something to the following
# function. In this case, the decorator defines a source (the drop down menu)
# and defines a destination (the graph).
# The following function (update_graph) converts the input (a file name)
# into an output (the specifications for a plot). There can be more than one
# # souce, which is why it is in a list.

# @app.callback(
#     Output(component_id='graph', component_property='figure'),
#     [Input(component_id='select', component_property='value')
#     ]
# )
# def update_graph(select):
#     # return a defined state if no file is picked
#     if file_list is None:
#         return None
#     print("In update_graph. You've selected'{}'".format(file_list))              # For debug
#
#     # actually graph the data
#     dcc.Graph(
#         id='graph',
#         figure={
#             'data': [trace1, trace2]
#         })
#
#     return {
#         'data' : [trace1, trace2]
#     }                  # Return the two lines (traces) for plotting.


# @app.callback(
#     Output(component_id='select', component_property='value'),
#     [Input(component_id='select', component_property='value')]
#     # [State('select', 'value')]
#      # Input(component_id='graph', component_property='clickData')
#      # Input(component_id='graph', component_property='selectedData')
#      # ]
# )
# def update_select_value(select):
#     print "In update_select_value. ", type(select), select
#     if (select is None) or (select == "---"):
#         return None
#     else:
#         return select
#


# @app.callback(
#     Output(component_id='graph', component_property='figure'),
#     [
#      Input(component_id='select', component_property='value'),
#      # Input(component_id='graph', component_property='clickData')
#      # Input(component_id='graph', component_property='selectedData')
#      ]
# )
# def update_graph(file_name):
#     # file_name = "Skip"
#     print "In update_graph", type(file_name), file_name
#     print file_name
#     if file_name is None:                               # Return a defined state if no file is picked
#         print m
#         trace1 = go.Scatter(x=m.index.values,  # Extract the data for the first line
#                             y=m['Temp (C)'],
#                             mode='lines+markers',
#                             name="mean1",
#                             customdata=m['File'],
#                             text=m['File']
#                             # hoverinfo
#                             )
#         trace2 = go.Scatter(x=m.index.values,  # and the data for the second line
#                             y=m['Temp2'],
#                             mode='lines+markers',
#                             name="mean2",
#                             # text=m['File']
#                             )
#         return {'data': [trace1, trace2]}  # Return the two lines (traces) for plotting.
#         # return {'data' : m}
#     print "In update_graph. You've selected'{}'".format(file_name)              # For debug
#     if not isinstance(file_name, list):
#         file_name = list(file_name)
#     # Read the excel file. We skip the first line becasue it is not part of the tabular data.
#     x1, y1, x2, y2 = [], [], [], []
#     for file in file_name:
#         print "In update_graph. Reading file ", file
#         df = pd.read_excel(file, header=1)
#         print df
#         x1.extend(df['Date']), y1.extend(df['Temp (C)'])
#         x2.extend(df['Date']), y2.extend(df['Temp2'])
#
#     # print x1, y1
#     trace1 = go.Scatter(x=x1,                   # Extract the data for the first line
#                         y=y1,
#                         mode='lines+markers',
#                         name="Tenp"
#                        )
#     trace2 = go.Scatter(x=x2,                   # and the data for the second line
#                         y=y2,
#                         mode='lines+markers',
#                         name="Tenp2",
#                         visible=False
#                        )
#     # print trace1
#     return {'data' : [trace1, trace2]}                  # Return the two lines (traces) for plotting.


@app.callback(
    Output(component_id='graph', component_property='figure'),
    [
     Input(component_id='select', component_property='value'),
     Input(component_id='graph', component_property='selectedData')
     # Input(component_id='graph', component_property='selectedData')
     ]
)
def update_graph2(file_name, clickData=None):
    print("In update_graph2. file_name ", file_name)
    print("clickData  ", type(clickData))
    print(isinstance(clickData, dict))

    if isinstance(clickData, dict):
        file_name1=[x['customdata'] for x in clickData['points']]
        print("isinstance(clickData, dict)", file_name1)
        return update_graph(file_name1)

    if (file_name is None):                               # Return a defined state if no file is picked
        print(m)
        trace1 = go.Scatter(x=m.index.values,  # Extract the data for the first line
                            y=m['Temp (C)'],
                            mode='markers+lines',
                            name="mean1",
                            customdata=m['File'],
                            text=m['File'],
                            hoveron='points',
                            ids=["pt_{:}".format(range(len(m.index.values)))],
                            marker={'size' : 20,
                                    'maxdisplayed' : 10}
                            # hoverinfo
                            )
        trace2 = go.Scatter(x=m.index.values,  # and the data for the second line
                            y=m['Temp2'],
                            mode='lines+markers',
                            name="mean2",
                            hoveron='points',
                            # text=m['File']
                            )

        return {'data': [trace1, trace2],
                'layout' : {'showlegend': True,
                            'dragmode' : 'lasso',
                            'xaxis' : {'title' : 'Date'},
                            'yaxis' : {'title' : 'Temp'}}}  # Return the two lines (traces) for plotting.

    print("Converting file_name to list", file_name, [file_name])
    return update_graph([file_name])

    # 'layout': {
    #     'margin': {'l': 15, 'r': 0, 'b': 15, 't': 5},
    #     'dragmode': 'select',
    #     'hovermode': 'closest',
    #     'showlegend': False
    # }

    print("clickData ", clickData)


if __name__ == '__main__':
    print("Running main.")

    # Open a Safari window to open -a Safari http://127.0.0.1:8050
    # subprocess.check_call(shlex.split("open -a Safari http://127.0.0.1:8050"))

    app.run_server(debug=True)


"""
I found this source helpful
http://pbpython.com/plotly-dash-intro.html

Other references:
https://dash.plot.ly/getting-started-part-2
https://medium.com/@plotlygraphs/introducing-plotly-py-3-0-0-7bb1333f69c6
https://plot.ly/python/line-and-scatter/
https://plot.ly/python/reference/

dash conda installations instructions at
https://stackoverflow.com/questions/49613878/python-install-dash-with-conda
conda install -c conda-forge dash-renderer
conda install -c conda-forge dash
conda install -c conda-forge dash-html-components
conda install -c conda-forge dash-core-components
conda install -c conda-forge plotly

"""
