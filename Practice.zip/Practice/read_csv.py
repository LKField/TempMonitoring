# Objective: learn to understand a csv file by  reading through it line by line

import csv
import pandas as pd
import datetime

with open('Test.csv') as csvfile:
    spamreader = csv.reader(csvfile)
    next(spamreader, None)
    dates = []
    temps = []
    humids = []

    for row in spamreader:
        #print(', '.join(row))
        date = row[0]
        temp = row[1]
        humid = row[2]

        dates.append(date)
        temps.append(temp)
        humids.append(humid)

    print(dates)
    print(temps)
    print(humids)
